'use strict';

/**
 * @ngdoc overview
 * @name myhouseApp
 * @description
 * # myhouseApp
 *
 * Main module of the application.
 */
angular.module('myhouseApp', [
    'ngRoute',
    'firebase'

  ]).config(function($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl',
        controllerAs: 'main'
      })
      .when('/quotes', {
        templateUrl: '/views/quotes.html',
        controller: 'QuotesCtrl',
        controllerAs: 'quotes',

      })
      .when('/quotes_panel', {
        templateUrl: 'views/quotes_panel.html',
        controller: 'QuotesPanelCtrl',
        controllerAs: 'quotesPanel'
      })
       .when('/inventory_table', {
        templateUrl: 'views/inventory_table.html',
        controller: 'InventoryTableCtrl',
        controllerAs: 'inventoryTablePanel'
      })
      .when('/quotes_detail', {
        templateUrl: 'views/quotes_detail.html',
        controller: 'QuotesDetailCtrl',
        controllerAs: 'quotesDetail'
      })
      .when('/materials_detail', {
        templateUrl: 'views/materials_detail.html',
        controller: 'MaterialsDetailCtrl',
        controllerAs: 'materialsDetail'
      })
      .when('/contact_detail', {
        templateUrl: 'views/contact_detail.html',
        controller: 'ContactDetailCtrl',
        controllerAs: 'contactDetail'
      })
      .when('/costs_detail', {
        templateUrl: 'views/costs_detail.html',
        controller: 'CostsDetailCtrl',
        controllerAs: 'costsDetail'
      })
      .when('/notes_detail', {
        templateUrl: 'views/notes_detail.html',
        controller: 'NotesDetailCtrl',
        controllerAs: 'notesDetail'
      })
      .when('/chat', {
        templateUrl: 'views/chat.html',
        controller: 'ChatCtrl',
        controllerAs: 'chat'
      })
      .when('/chat-active', {
        templateUrl: 'views/chat-active.html',
        controller: 'ChatActiveCtrl',
        controllerAs: 'chatActive'
      })
      .when('/inventory', {
        templateUrl: 'views/inventory.html',
        controller: 'InventoryCtrl',
        controllerAs: 'inventory'
      })
      .when('/inventory_change', {
        templateUrl: 'views/inventory_change.html',
        controller: 'InventoryChangeCtrl',
        controllerAs: 'inventoryChange'
      })
      .when('/file_upload', {
        templateUrl: 'views/file_upload.html',
        controller: 'FileUploadCtrl',
        controllerAs: 'fileUpload'
      })
      .when('/client_info', {
        templateUrl: 'views/client_info.html',
        controller: 'ClientInfoCtrl',
        controllerAs: 'clientInfo'
      })
      .when('/clients', {
        templateUrl: 'views/clients.html',
        controller: 'ClientsCtrl',
        controllerAs: 'clients'
      })
      .when('/costs', {
        templateUrl: 'views/costs.html',
        controller: 'CostsCtrl',
        controllerAs: 'costs'
      })
      .when('/admin_control', {
        templateUrl: 'views/admin_control.html',
        controller: 'AdminControlCtrl',
        controllerAs: 'adminControl'
      })
      .when('/users_table', {
        templateUrl: 'views/users_table.html',
        controller: 'UsersCtrl',
        controllerAs: 'users'
      })
      .when('/list', {
        templateUrl: 'views/list.html',
        controller: 'ListCtrl',
        controllerAs: 'list'
      })
     
      .when('/submitted_quotes_table', {
        templateUrl: 'views/submitted_quotes_table.html',
        controller: 'AddMaterialsCtrl',
        controllerAs: 'addMaterials'
      })
      .when('/clients_table', {
        templateUrl: 'views/clients_table.html',
        controller: 'ClientsTableCtrl',
        controllerAs: 'clientstable'
      })
      .otherwise({
        redirectTo: '/'
      });
  });